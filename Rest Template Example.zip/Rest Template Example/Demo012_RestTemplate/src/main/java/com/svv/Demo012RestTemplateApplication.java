package com.svv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo012RestTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo012RestTemplateApplication.class, args);
	}

}
