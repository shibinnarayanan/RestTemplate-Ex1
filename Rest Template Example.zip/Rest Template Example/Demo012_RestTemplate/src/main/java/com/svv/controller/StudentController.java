package com.svv.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.svv.model.StudentInfo;

@RestController
public class StudentController {
	
	@PostMapping(value = "/saveStudent" , consumes = {"application/json","application/xml"})
	public ResponseEntity<StudentInfo> generateStudentFile(@RequestBody StudentInfo studInfo)
	{
		String url = "http://localhost:1010/generateFile";
		RestTemplate restTmp = new RestTemplate();
		
		HttpEntity<StudentInfo> reqEntity = new HttpEntity<>(studInfo);
		
		ResponseEntity<StudentInfo> response = restTmp.postForEntity(url, reqEntity, StudentInfo.class);

		return response;
	}
}

