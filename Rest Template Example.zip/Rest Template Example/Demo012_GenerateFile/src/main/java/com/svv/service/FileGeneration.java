package com.svv.service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.svv.model.StudentInfo;

public class FileGeneration implements Runnable {

	private StudentInfo stdInfo;

	public FileGeneration(StudentInfo stdInfo) {
		super();
		this.stdInfo = stdInfo;
	}

	@Override
	public void run() {
		String name = stdInfo.getName();

		String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());

		String fileName = "C:\\Users\\HP Pavilion\\Desktop\\tempLoc\\" + name + "_" + fileSuffix + ".txt";

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter printWriter = new PrintWriter(fileWriter);
		printWriter.println("Student Name " + name);
		printWriter.println("Student Age " + stdInfo.getAge());
		printWriter.println("Student Name " + stdInfo.getAddress());
		printWriter.close();
	}

}
