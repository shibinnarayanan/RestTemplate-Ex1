package com.svv.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svv.model.StudentInfo;
import com.svv.service.FileGeneratorService;

@RestController
public class FileGeneratorController {
	
	@Autowired
	FileGeneratorService service;
	
	@PostMapping(value = "/generateFile" , consumes = {"application/json","application/xml"})
	public void generateFile(@RequestBody StudentInfo studInfo)
	{
		try {
			service.generateFile(studInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
