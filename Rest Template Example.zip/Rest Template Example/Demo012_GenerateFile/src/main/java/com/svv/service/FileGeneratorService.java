package com.svv.service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Service;

import com.svv.model.StudentInfo;

@Service
public class FileGeneratorService {
	
	public void generateFile(StudentInfo stdInfo) throws IOException
	{
		  ExecutorService execServ = Executors.newFixedThreadPool(10);
		  
		  execServ.execute(new FileGeneration(stdInfo));
	}


}
